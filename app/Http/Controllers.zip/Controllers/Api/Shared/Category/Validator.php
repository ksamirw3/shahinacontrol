<?php

namespace App\Http\Controllers\Api\Shared\Category;

class Validator extends \App\Http\Controllers\Api\BaseValidator {

	protected $url = 'api/driver/orders/';

}
