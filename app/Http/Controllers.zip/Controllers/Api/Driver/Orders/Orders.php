<?php

namespace App\Http\Controllers\Api\Driver\Orders;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Orders
 *
 * @author JooAziz
 */
use App\Models\Order as Model;
use App\Http\Controllers\Api\Driver\Orders\Validator as Checker;
use App\Models\Order;
use Carbon\Carbon;
use JooAziz\Response\Response;

class Orders extends \App\Http\Controllers\Api\Base {

    public function anyFirstOrderDate() {
        if (!request()->driver_id)
            return Response::make()->setMessage('driver id not valid')->send();
        $order = Order::whereDriverId(request()->driver_id)->first();
        if (!$order)
            return Response::make()->setMessage('no orders yet')->send();
        return Response::make()->setResult(true)->setData(['date' => @$order->created_at->toDateTimeString()])->send();
    }

    public function anyOpen(Checker $d) {
        $res = Model::getOrdersForDriver(request()->driver_id, Model::$open);
        return Response::make()->setData(['ordersList' => $res])->setResult(TRUE)->send();
    }

    public function anyRejected(Checker $d) {
        $res = Model::getOrdersForDriver(request()->driver_id, Model::$rejected);
        return Response::make()->setData(['ordersList' => $res])->setResult(TRUE)->send();
    }

    public function anyExecuted(Checker $d) {
        $res = Model::getOrdersForDriver(request()->driver_id, Model::$executed);
        return Response::make()->setData(['ordersList' => $res])->setResult(TRUE)->send();
    }

    public function anyUpdate() {
        $order = Model::find(request()->order_id);
        $order->{request()->key} = request()->val;
        $order->save();
        return Response::make()->setResult(TRUE)->send();
    }

}
